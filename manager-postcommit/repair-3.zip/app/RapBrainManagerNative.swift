import AppKit
import Foundation

final class ManagerApp: NSObject, NSApplicationDelegate, NSWindowDelegate {
    private var window: NSWindow!
    private var statusLabel: NSTextField!
    private var openButton: NSButton!
    private var process: Process?
    private var pipe: Pipe?
    private var stdoutBuffer = Data()
    private var dashboardURL: URL?
    private var logHandle: FileHandle?

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        let rect = NSRect(x: 0, y: 0, width: 470, height: 205)
        window = NSWindow(contentRect: rect, styleMask: [.titled, .closable, .miniaturizable], backing: .buffered, defer: false)
        window.title = "Rap Brain Manager — Bêta 13"
        window.center()
        window.delegate = self
        let content = window.contentView!
        statusLabel = NSTextField(labelWithString: "Démarrage du tableau de bord…")
        statusLabel.frame = NSRect(x: 26, y: 115, width: 418, height: 55)
        statusLabel.lineBreakMode = .byWordWrapping
        statusLabel.maximumNumberOfLines = 3
        content.addSubview(statusLabel)
        openButton = NSButton(title: "Ouvrir le tableau de bord", target: self, action: #selector(openDashboard))
        openButton.frame = NSRect(x: 22, y: 49, width: 240, height: 38)
        openButton.isEnabled = false
        content.addSubview(openButton)
        let quitButton = NSButton(title: "Quitter", target: self, action: #selector(quit))
        quitButton.frame = NSRect(x: 344, y: 49, width: 96, height: 38)
        content.addSubview(quitButton)
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        startManager()
    }

    private func setupLog() {
        let logs = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Library/Logs")
        try? FileManager.default.createDirectory(at: logs, withIntermediateDirectories: true)
        let path = logs.appendingPathComponent("RapBrainManager-Beta13.log")
        if !FileManager.default.fileExists(atPath: path.path) { FileManager.default.createFile(atPath: path.path, contents: nil) }
        logHandle = FileHandle(forWritingAtPath: path.path)
        logHandle?.seekToEndOfFile()
    }
    private func record(_ bytes: Data) { logHandle?.write(bytes) }

    private func startManager() {
        setupLog()
        let resources = Bundle.main.resourceURL!
        let script = resources.appendingPathComponent("launch_manager.py")
        let candidates = ["/Library/Frameworks/Python.framework/Versions/Current/bin/python3", "/opt/homebrew/bin/python3", "/usr/local/bin/python3", "/usr/bin/python3"]
        guard let python = candidates.first(where: { FileManager.default.isExecutableFile(atPath: $0) }) else {
            statusLabel.stringValue = "Python introuvable. Installer Python 3.9+ avant de démarrer."
            return
        }
        let child = Process()
        child.executableURL = URL(fileURLWithPath: python)
        child.arguments = [script.path, "--candidate", resources.appendingPathComponent("candidate").path, "--no-browser"]
        child.currentDirectoryURL = resources
        child.environment = ProcessInfo.processInfo.environment.merging(["PYTHONUNBUFFERED":"1", "PYTHONDONTWRITEBYTECODE":"1"]) { _,new in new }
        let stream = Pipe()
        child.standardOutput = stream
        child.standardError = stream
        pipe = stream
        process = child
        stream.fileHandleForReading.readabilityHandler = { [weak self] handle in
            let bytes = handle.availableData
            guard !bytes.isEmpty else { return }
            DispatchQueue.main.async { self?.consume(bytes) }
        }
        child.terminationHandler = { [weak self] proc in
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.openButton.isEnabled = self.dashboardURL != nil
                if proc.terminationReason == .exit && proc.terminationStatus == 42 {
                    NSApp.terminate(nil)
                    return
                }
                if self.dashboardURL == nil { self.statusLabel.stringValue = "Le Manager a quitté (code \(proc.terminationStatus)). Consulte ~/Library/Logs/RapBrainManager-Beta13.log" }
            }
        }
        do { try child.run() }
        catch { statusLabel.stringValue = "Lancement impossible : \(error.localizedDescription)" }
    }

    private func consume(_ bytes: Data) {
        record(bytes)
        stdoutBuffer.append(bytes)
        while let newline = stdoutBuffer.firstIndex(of: 10) {
            let line = Data(stdoutBuffer.prefix(upTo: newline))
            stdoutBuffer.removeSubrange(...newline)
            let text = String(decoding: line, as: UTF8.self)
            if let range = text.range(of: "Tableau de bord : ") {
                let address = String(text[range.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
                if let url = URL(string: address), url.scheme == "http", url.host == "127.0.0.1" {
                    dashboardURL = url
                    statusLabel.stringValue = "Manager démarré. Tableau de bord disponible sur \(address)"
                    openButton.isEnabled = true
                    NSWorkspace.shared.open(url)
                }
            }
        }
        if stdoutBuffer.count > 65536 { stdoutBuffer.removeFirst(stdoutBuffer.count - 65536) }
    }
    @objc private func openDashboard() { if let url = dashboardURL { NSWorkspace.shared.open(url) } }
    @objc private func quit() { NSApp.terminate(nil) }
    func windowWillClose(_ notification: Notification) { NSApp.terminate(nil) }
    func applicationWillTerminate(_ notification: Notification) {
        pipe?.fileHandleForReading.readabilityHandler = nil
        if let p = process, p.isRunning {
            p.terminate()
            let deadline = Date().addingTimeInterval(4)
            while p.isRunning && Date() < deadline { Thread.sleep(forTimeInterval: 0.1) }
            // Avoid killing unrelated processes: only terminate the owned child.
            if p.isRunning { p.interrupt() }
        }
        logHandle?.closeFile()
    }
}
let app = NSApplication.shared
let delegate = ManagerApp()
app.delegate = delegate
app.run()
