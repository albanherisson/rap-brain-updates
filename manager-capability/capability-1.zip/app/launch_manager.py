#!/usr/bin/env python3
"""Rap Brain Manager Beta: local, read-only preview of the real manager UI.
Does not launch the installed .app or authorize any updater operations.
"""
import argparse, hashlib, http.client, json, os, shutil, subprocess, sys, tempfile, time, webbrowser
from pathlib import Path

CHILD = r'''import importlib.util, json, os, socket, sys, threading, http.client, sqlite3, tempfile, hashlib, shutil, datetime, time
from pathlib import Path
read_only_network=threading.local()
root=Path(sys.argv[1]).resolve();source=Path(sys.argv[2]).resolve();host_source=Path(sys.argv[3]).resolve();backup_root=Path(sys.argv[4]).resolve()
if Path.home().resolve()!=root:raise RuntimeError('home_not_isolated')
def audit(event,args):
 if event.startswith('subprocess.') or event in ('os.system','os.exec','os.spawn','os.posix_spawn'):
  raise RuntimeError('process_denied:'+event)
 if event=='socket.connect':
  address=args[1] if len(args)>1 else None
  # Permit HTTPS only during the explicitly allowed informational GitHub check.
  if not ((getattr(read_only_network,'active',False) and isinstance(address,tuple) and len(address)>=2 and address[1]==443) or (getattr(read_only_network,'rap_health',False) and isinstance(address,tuple) and address==('127.0.0.1',8765))):
   raise RuntimeError('socket_connect_denied')
 if event=='socket.bind':
  addr=args[1]
  if not isinstance(addr,tuple) or addr[0]!='127.0.0.1' or addr[1]!=0:raise RuntimeError('non_ephemeral_bind_denied')
 if event=='open' and len(args)>=2:
  mode=args[1];flags=args[2] if len(args)>=3 else 0
  writes=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
  if writes:
   target=Path(args[0]) if isinstance(args[0],(str,bytes,os.PathLike)) else None
   if target is None or not (target.resolve().is_relative_to(root) or target.resolve().is_relative_to(backup_root)):raise RuntimeError('write_outside_allowed_areas_denied')
sys.addaudithook(audit)
spec=importlib.util.spec_from_file_location('rc40_manager',source)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
# Host Rap Brain path is visible for status checks only; all POST actions remain blocked.
m.SOURCE=host_source
def deny_post(self):self.send(403,b'{"error":"Mode apercu : modifications desactivees"}','application/json')
# Keep the original handler for one authenticated, informational operation only.
original_post=m.Handler.do_POST
def readonly_post(self):
 if self.path!='/api/check-public-channel':return deny_post(self)
 read_only_network.active=True
 try:return original_post(self)
 finally:read_only_network.active=False
m.Handler.do_POST=readonly_post
import hashlib, secrets, shutil
from urllib.parse import urlsplit
active=root/'rapbrain_fictif';active.mkdir()
(active/'version.txt').write_text('1.0-test',encoding='utf8')
shutil.copyfile(root/'manager.py',active/'manager.py')
original_sha=hashlib.sha256((active/'manager.py').read_bytes()).hexdigest()
(active/'library.json').write_text('{"tracks":["exemple-conserve"]}',encoding='utf8')
backup=root/'backup-fictif'
auth=secrets.token_urlsafe(32)
def snapshot():
 return {'version':(active/'version.txt').read_text().strip(),'library':json.loads((active/'library.json').read_text()),'backup_exists':backup.exists(),'manager_sha256':hashlib.sha256((active/'manager.py').read_bytes()).hexdigest(),'original_sha256':original_sha,'original_restored':hashlib.sha256((active/'manager.py').read_bytes()).hexdigest()==original_sha}
def page():
 s=snapshot();b=lambda v:str(v).lower()
 return ("""<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Rap Brain Manager — Essais</title><style>body{background:#101722;color:#edf2fb;font:16px system-ui;margin:5vh auto;max-width:800px;padding:20px}section{background:#1d2939;padding:28px;border-radius:18px}button{background:#a9d7ff;border:0;border-radius:8px;padding:13px;margin:6px;cursor:pointer}a{color:#a9d7ff}pre{padding:15px;background:#0b1220;border-radius:8px;white-space:pre-wrap}</style><section><h1>Rap Brain Manager — version bêta</h1><p>Essais sur une <strong>copie temporaire du vrai manager.py</strong>. La démonstration ne modifie pas les données ou le Manager installés. Pour ouvrir Rap Brain, son serveur doit déjà fonctionner.</p><p><a href="/">Voir l'interface originale du Manager</a> &nbsp;•&nbsp; <a href="http://127.0.0.1:8765/" target="_blank" rel="noopener noreferrer">Ouvrir Rap Brain (si déjà démarré)</a></p><pre id="state">Chargement…</pre><button onclick="action('backup')">1. Sauvegarder</button><button onclick="action('update')">2. Modifier la copie (test)</button><button onclick="action('restore')">3. Restaurer</button><pre id="report"></pre></section><script>const token='""" +auth+ """';async function refresh(){const r=await fetch('/api/demo/status');document.getElementById('state').textContent=JSON.stringify(await r.json(),null,2)}async function action(name){try{const r=await fetch('/api/demo/'+name,{method:'POST',headers:{'X-Demo-Token':token}});const x=await r.json();document.getElementById('report').textContent=JSON.stringify(x,null,2)}catch(e){document.getElementById('report').textContent=e.message}await refresh()}refresh()</script></html>""").encode()
def rap_health():
 read_only_network.rap_health=True
 try:
  c=http.client.HTTPConnection('127.0.0.1',8765,timeout=1.25)
  try:
   c.request('GET','/')
   res=c.getresponse();res.read(2048)
   return {'reachable':True,'http_status':res.status,'url':'http://127.0.0.1:8765/','note':'Réponse HTTP du serveur, sans authentifier son identité'}
  finally:c.close()
 except (OSError,TimeoutError,http.client.HTTPException):
  return {'reachable':False,'url':'http://127.0.0.1:8765/','note':'Pas de réponse HTTP sur le port 8765'}
 finally:read_only_network.rap_health=False

def data_inventory():
 # Inspection read-only of file names/size only. No recursion through symlinks.
 allowed={'.db','.sqlite','.sqlite3','.json','.jsonl','.ndjson'}
 skip={'.git','.venv','venv','node_modules','__pycache__','.cache','runtime','backups','backup','models'}
 found=[];total=0;truncated=False
 if not host_source.is_dir():return {'source_exists':False,'candidates':[],'truncated':False}
 for base,dirs,files in os.walk(host_source,followlinks=False):
  basepath=Path(base)
  dirs[:]=sorted(d for d in dirs if d not in skip and not (basepath/d).is_symlink())
  if len(basepath.relative_to(host_source).parts)>5:dirs[:]=[];continue
  for name in sorted(files):
   path=basepath/name
   if path.suffix.lower() not in allowed or path.is_symlink():continue
   try:stat=path.stat()
   except OSError:continue
   found.append({'path':str(path.relative_to(host_source)),'bytes':stat.st_size})
   total+=stat.st_size
   if len(found)>=120:truncated=True;break
  if truncated:break
 return {'source_exists':True,'candidates':found,'total_candidate_bytes':total,'truncated':truncated,'backup_created':False,'notice':'Inventaire indicatif, pas une sauvegarde complète'}


# Persists snapshots only in a dedicated backup directory, never in Rap Brain itself.
backup_guard=threading.Lock()
backup_token=secrets.token_urlsafe(32)
def ensure_safe_backup_root():
 if not backup_root.is_dir() or backup_root.is_symlink():raise RuntimeError('backup_directory_not_safe')
 if backup_root==host_source or backup_root.is_relative_to(host_source) or host_source.is_relative_to(backup_root):raise RuntimeError('backup_overlaps_source')
 if not (host_source/'data'/'rapbrain.sqlite3').is_file():raise FileNotFoundError('base SQLite active introuvable')
 if (host_source/'data'/'rapbrain.sqlite3').is_symlink():raise RuntimeError('sqlite_source_symlink_denied')

def history():
 rows=[]
 if not backup_root.is_dir():return {'backups':rows,'backup_root':str(backup_root)}
 for d in sorted(backup_root.iterdir(),reverse=True):
  if len(rows)>=50:break
  if d.is_symlink() or not d.is_dir() or not d.name.startswith('rb-'):continue
  f=d/'manifest.json'
  if not f.is_file() or f.is_symlink():continue
  try:
   mfest=json.loads(f.read_text(encoding='utf8'))
   db=d/'rapbrain.sqlite3'
   if db.is_symlink() or not db.is_file():continue
   rows.append({'id':d.name,'created_at':mfest.get('created_at'),'sqlite_bytes':mfest.get('sqlite_bytes'),'sqlite_sha256':mfest.get('sqlite_sha256'),'integrity':mfest.get('sqlite_quick_check'),'configuration_saved':mfest.get('config_saved',False)})
  except (ValueError,OSError):continue
 return {'backups':rows,'backup_root':str(backup_root),'restoration_enabled':False}

def backup_live_db():
 ensure_safe_backup_root()
 with backup_guard:
  source_db=host_source/'data'/'rapbrain.sqlite3'
  stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
  tag='rb-'+stamp+'-'+secrets.token_hex(3)
  dest=backup_root/tag
  if dest.exists():raise RuntimeError('backup_collision')
  temp_dir=Path(tempfile.mkdtemp(prefix='.incomplete-',dir=backup_root))
  try:
   target=temp_dir/'rapbrain.sqlite3'
   # SQLite Online Backup API: coherent snapshot even if database is open (WAL included).
   original=sqlite3.connect(f'file:{source_db}?mode=ro',uri=True,timeout=12)
   try:
    copy=sqlite3.connect(str(target),timeout=12)
    try:
     original.backup(copy,pages=128,sleep=0.1)
     check=copy.execute('PRAGMA quick_check').fetchone()[0]
     if check!='ok':raise RuntimeError('sqlite_quick_check_failed')
    finally:copy.close()
   finally:original.close()
   def digest(file):
    h=hashlib.sha256()
    with file.open('rb') as stream:
     for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
   meta={'schema':'rapbrain-manager-backup-v1','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sqlite_bytes':target.stat().st_size,'sqlite_sha256':digest(target),'sqlite_quick_check':check,'config_saved':False,'source_db':'data/rapbrain.sqlite3'}
   config=host_source/'data'/'ollama_model.json'
   if config.is_file() and not config.is_symlink() and config.stat().st_size<=1024*1024:
    shutil.copyfile(config,temp_dir/'ollama_model.json')
    meta['config_saved']=True
    meta['config_sha256']=digest(temp_dir/'ollama_model.json')
   (temp_dir/'manifest.json').write_text(json.dumps(meta,indent=2,ensure_ascii=False),encoding='utf8')
   temp_dir.rename(dest)
   return {'ok':True,'backup_id':tag,'path':str(dest),'manifest':meta,'message':'Sauvegarde SQLite vérifiée. Restauration réelle désactivée.'}
  finally:
   if temp_dir.exists():shutil.rmtree(temp_dir)


def verify_restore_to_separate_folder():
 # Never restore into the live Rap Brain tree. Compare content with a previously verified backup.
 with backup_guard:
  options=history()['backups']
  if not options:raise RuntimeError('no_backup_available')
  entry=options[0]
  backup_id=entry['id']
  if not (backup_id.startswith('rb-') and all(ch.isalnum() or ch=='-' for ch in backup_id)):
   raise RuntimeError('unsafe_backup_id')
  source_dir=backup_root/backup_id
  if source_dir.is_symlink() or not source_dir.is_dir():raise RuntimeError('unsafe_backup_directory')
  mf=source_dir/'manifest.json'; db=source_dir/'rapbrain.sqlite3'
  if any(x.is_symlink() or not x.is_file() for x in (mf,db)):raise RuntimeError('unsafe_backup_files')
  metadata=json.loads(mf.read_text(encoding='utf8'))
  if metadata.get('schema')!='rapbrain-manager-backup-v1':raise RuntimeError('unknown_manifest_schema')
  if metadata.get('source_db')!='data/rapbrain.sqlite3':raise RuntimeError('unknown_source_layout')
  def digest(path):
   h=hashlib.sha256()
   with path.open('rb') as f:
    for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
   return h.hexdigest()
  expected=metadata.get('sqlite_sha256')
  if not isinstance(expected,str) or len(expected)!=64 or digest(db)!=expected:raise RuntimeError('backup_sha256_mismatch')
  if db.stat().st_size!=metadata.get('sqlite_bytes'):raise RuntimeError('backup_size_mismatch')
  config_file=source_dir/'ollama_model.json'
  include_config=metadata.get('config_saved') is True
  if include_config:
   if config_file.is_symlink() or not config_file.is_file() or digest(config_file)!=metadata.get('config_sha256'):
    raise RuntimeError('config_sha256_mismatch')
  elif config_file.exists():raise RuntimeError('unexpected_config_file')
  # Test output is never under the Rap Brain installation. Never replace an existing test.
  trials=backup_root/'restore-tests'
  if trials.is_symlink():raise RuntimeError('unsafe_trial_root')
  trials.mkdir(exist_ok=True)
  dest=trials/(backup_id+'-'+secrets.token_hex(4))
  dest.mkdir(mode=0o700)
  try:
   target=dest/'rapbrain.sqlite3'
   shutil.copyfile(db,target)
   if include_config:shutil.copyfile(config_file,dest/'ollama_model.json')
   if digest(target)!=expected:raise RuntimeError('restored_sha256_mismatch')
   con=sqlite3.connect('file:'+str(target)+'?mode=ro',uri=True,timeout=5)
   try: check=con.execute('PRAGMA quick_check').fetchone()[0]
   finally:con.close()
   if check!='ok':raise RuntimeError('restored_integrity_failed')
   return {'ok':True,'action':'restore_test','backup_id':backup_id,
           'restored_to':str(dest),'original_sha256':expected,
           'restored_sha256':digest(target),'identical':True,
           'sqlite_quick_check':check,'config_restored':include_config,
           'live_database_modified':False,'real_restoration_enabled':False}
  except Exception:
   shutil.rmtree(dest)
   raise


# Beta 7: delegate explicit launch requests to the parent supervisor. Never spawn here.
def launch_request():
 if not (host_source/'server.py').is_file() or (host_source/'server.py').is_symlink():
  return {'ok':False,'reason':'server.py introuvable ou lien symbolique','launched':False}
 current=rap_health()
 if current['reachable']:
  return {'ok':False,'reason':'Port 8765 déjà occupé : aucun démarrage effectué','launched':False}
 req=root/'launch-request.json'
 if req.exists():return {'ok':False,'reason':'Demande déjà en cours','launched':False}
 req.write_text(json.dumps({'action':'start','token':launch_token,'script':'server.py'}))
 return {'ok':True,'queued':True,'launched':False,'message':'Demande transmise au contrôleur. Actualiser le statut.'}
launch_token=secrets.token_urlsafe(32)
signature_token=secrets.token_urlsafe(32)
ENGINE_PANEL="""<section style="background:#16243a;color:#e9f1ff;border:1px solid #334967;border-radius:18px;padding:20px;margin:18px auto;max-width:970px;font:15px system-ui"><h2>Creative Engine — essai de mise à jour</h2><p>Teste le remplacement et le retour arrière du fichier moteur dans un dossier temporaire. La signature est temporaire et propre à ce test ; aucune version officielle du Creative Engine n'est publiée ou installée.</p><button onclick="rbEngineTrial()">Tester mise à jour + retour arrière du Creative Engine</button><pre id="rb-engine-result" style="white-space:pre-wrap;max-height:350px;overflow:auto"></pre><p><strong>Mise à jour réelle en un clic :</strong> en attente d’un paquet Creative Engine signé et publié.</p></section><script>const rbEngineToken="""+json.dumps(signature_token)+""";async function rbEngineTrial(){if(!confirm('Essai dans un dossier temporaire uniquement ?'))return;const e=document.getElementById('rb-engine-result');e.textContent='Essai en cours…';const r=await fetch('/api/rapbrain/engine-trial',{method:'POST',headers:{'X-RB-Engine-Token':rbEngineToken}});e.textContent=JSON.stringify(await r.json(),null,2);for(let n=0;n<90;n++){await new Promise(done=>setTimeout(done,450));const data=await(await fetch('/api/rapbrain/engine-trial-state')).json();if(data.state==='finished'||data.state==='failed'){e.textContent=JSON.stringify(data,null,2);break}}}</script>"""

SIGNATURE_PANEL="""<section style="background:#16243a;color:#e9f1ff;border:1px solid #334967;border-radius:18px;padding:20px;margin:18px auto;max-width:970px;font:15px system-ui"><h2>Canal signé — vérification locale (Bêta 8)</h2><p>Contrôle la signature Ed25519 de notre ancienne candidate RC24/RC25, sans installation ni modification. Ce test ne publie aucune mise à jour.</p><button onclick="rbSignedCheck()">Vérifier la candidate signée</button><pre id="rb-signed-report" style="white-space:pre-wrap;max-height:360px;overflow:auto"></pre></section><script>const rbSignatureToken="""+json.dumps(signature_token)+""";async function rbSignedState(){const r=await fetch('/api/rapbrain/signed-state');document.getElementById('rb-signed-report').textContent=JSON.stringify(await r.json(),null,2)}async function rbSignedCheck(){const r=await fetch('/api/rapbrain/check-signed',{method:'POST',headers:{'X-RB-Signature-Token':rbSignatureToken}});document.getElementById('rb-signed-report').textContent=JSON.stringify(await r.json(),null,2);setTimeout(rbSignedState,1500)}rbSignedState()</script>"""

REHEARSAL_PANEL="""<section style="background:#16243a;color:#e9f1ff;border:1px solid #334967;border-radius:18px;padding:20px;margin:18px auto;max-width:970px;font:15px system-ui"><h2>Mise à jour signée — répétition sur copies (Bêta 9)</h2><p>Vérifie la signature RC25, remplace une copie du Manager par une copie signée, puis restaure exactement l'original. N'installe rien et ne modifie pas Rap Brain.</p><button onclick="rbRehearse()">Tester remplacement + restauration sur copies</button><pre id="rb-rehearse-report" style="white-space:pre-wrap;max-height:380px;overflow:auto"></pre></section><script>const rbRehearsalToken="""+json.dumps(signature_token)+""";async function rbRehearse(){if(!confirm('Exécuter uniquement une répétition sur copies temporaires, sans installation ?'))return;const el=document.getElementById('rb-rehearse-report');el.textContent='Vérification de signature et essai en cours…';try{const r=await fetch('/api/rapbrain/rehearse-signed',{method:'POST',headers:{'X-RB-Rehearsal-Token':rbRehearsalToken}});el.textContent=JSON.stringify(await r.json(),null,2);for(let i=0;i<80;i++){await new Promise(res=>setTimeout(res,500));const st=await(await fetch('/api/rapbrain/rehearsal-state')).json();if(st.state==='finished'||st.state==='failed'){el.textContent=JSON.stringify(st,null,2);break}}}catch(e){el.textContent=String(e)}}</script>"""

START_PANEL="""<section style="background:#16243a;color:#e9f1ff;border:1px solid #334967;border-radius:18px;padding:20px;margin:18px auto;max-width:970px;font:15px system-ui"><h2>Rap Brain — lancement contrôlé (Bêta 7)</h2><p>Démarrage manuel uniquement. Aucun serveur existant n'est arrêté. L'arrêt reste désactivé tant que les décodages en cours ne sont pas détectables.</p><button onclick="rbLaunch()">Démarrer Rap Brain (si arrêté)</button><button onclick="rbLaunchState()">État du lancement</button> <a href="http://127.0.0.1:8765/" target="_blank" rel="noopener noreferrer">Ouvrir Rap Brain</a><pre id="rb-launch-report" style="white-space:pre-wrap;max-height:320px;overflow:auto"></pre></section><script>const rbLaunchToken=""" + json.dumps(launch_token) + """;async function rbLaunchState(){const r=await fetch('/api/rapbrain/launch-state');document.getElementById('rb-launch-report').textContent=JSON.stringify(await r.json(),null,2)}async function rbLaunch(){if(!confirm('Lancer server.py de ton dossier Rap Brain ? Le serveur pourra utiliser ses données réelles. Aucun processus existant ne sera arrêté.'))return;const r=await fetch('/api/rapbrain/start',{method:'POST',headers:{'X-RB-Launch-Token':rbLaunchToken}});document.getElementById('rb-launch-report').textContent=JSON.stringify(await r.json(),null,2);setTimeout(rbLaunchState,1500)}rbLaunchState()</script>"""

BACKUP_PANEL='<section id="rb-backup-panel" style="background:#16243a;color:#e9f1ff;border:1px solid #334967;border-radius:18px;padding:20px;margin:18px auto;max-width:970px;font:15px system-ui"><h2>Sauvegardes Rap Brain</h2><p>Copie cohérente de la base SQLite actuelle, avec contrôle d’intégrité et SHA-256. Restauration réelle désactivée. Test de restauration dans un dossier séparé.</p><button onclick="rbBackup()">Sauvegarder maintenant</button><button onclick="rbHistory()">Historique des sauvegardes</button><button onclick="rbRestoreTest()">Tester une restauration séparée</button><pre id="rb-backup-report" style="white-space:pre-wrap;max-height:350px;overflow:auto"></pre></section><script>const rbBackupToken="' + backup_token + '";async function rbHistory(){const o=await (await fetch(\'/api/rapbrain/backups\')).json();document.getElementById(\'rb-backup-report\').textContent=JSON.stringify(o,null,2)}async function rbBackup(){if(!confirm(\'Créer une sauvegarde vérifiée de la base actuelle ?\'))return;const el=document.getElementById(\'rb-backup-report\');el.textContent=\'Sauvegarde SQLite en cours…\';try{const r=await fetch(\'/api/rapbrain/backup\',{method:\'POST\',headers:{\'X-RB-Backup-Token\':rbBackupToken}});el.textContent=JSON.stringify(await r.json(),null,2)}catch(e){el.textContent=String(e)}}async function rbRestoreTest(){if(!confirm(\'Tester la restauration de la plus récente sauvegarde dans un dossier séparé ? La base active ne sera pas remplacée.\'))return;const el=document.getElementById(\'rb-backup-report\');el.textContent=\'Vérification en cours…\';try{const r=await fetch(\'/api/rapbrain/restore-test\',{method:\'POST\',headers:{\'X-RB-Backup-Token\':rbBackupToken}});el.textContent=JSON.stringify(await r.json(),null,2)}catch(e){el.textContent=String(e)}}rbHistory()</script>'

PANEL='<section id="rapbrain-health-panel" style="background:#16243a;color:#e9f1ff;border:1px solid #334967;border-radius:18px;padding:20px;margin:18px auto;max-width:970px;font:15px system-ui"><h2>Rap Brain — état et données</h2><p id="rb-health">Vérification du serveur local…</p><button onclick="rbStatus()">Actualiser le serveur</button> <button onclick="rbInventory()">Repérer les fichiers de données</button><p style="opacity:.8">Lecture seule. Aucun lancement, aucune sauvegarde ni mise à jour automatique.</p><pre id="rb-inventory" style="white-space:pre-wrap;max-height:300px;overflow:auto"></pre></section><script>async function rbStatus(){try{const r=await fetch(\'/api/rapbrain/health\');const v=await r.json();document.getElementById(\'rb-health\').textContent=v.reachable?\'Serveur HTTP accessible sur 8765 (statut \'+v.http_status+\')\':\'Serveur non joignable sur 8765\';}catch(e){document.getElementById(\'rb-health\').textContent=\'Contrôle indisponible\';}}async function rbInventory(){try{const r=await fetch(\'/api/rapbrain/inventory\');const v=await r.json();document.getElementById(\'rb-inventory\').textContent=JSON.stringify(v,null,2)}catch(e){document.getElementById(\'rb-inventory\').textContent=\'Inventaire indisponible\';}}rbStatus();</script>'
def beta13_html():
 template=(root/'dashboard_beta14.html').read_text(encoding='utf-8')
 tokens={'__BACKUP_TOKEN__':backup_token,'__LAUNCH_TOKEN__':launch_token,'__SIGNATURE_TOKEN__':signature_token}
 for k,v in tokens.items():template=template.replace(k,json.dumps(v)[1:-1])
 return template.encode('utf-8')

class DemoHandler(m.Handler):
 def send(self,code,blob,contenttype):
  if self.path=='/classic' and code==200 and contenttype.startswith('text/html'):
   blob=blob.replace(b'</body>',(PANEL+BACKUP_PANEL+START_PANEL+SIGNATURE_PANEL+REHEARSAL_PANEL+ENGINE_PANEL).encode()+b'</body>')
  return super().send(code,blob,contenttype)
 def do_GET(self):
  if urlsplit(self.path).path=='/':
   return self.send(200,beta13_html(),'text/html; charset=utf-8')
  if urlsplit(self.path).path=='/beta13-icon.png':
   return self.send(200,(root/'beta13-icon.png').read_bytes(),'image/png')
  if urlsplit(self.path).path=='/classic':
   old_path=self.path
   try:
    self.path='/'
    return super().do_GET()
   finally:self.path=old_path
  if urlsplit(self.path).path=='/api/rapbrain/manager-update-state':
   f=root/'manager-update-result.json'
   secure=backup_root/'secure-update'
   try:
    if (secure/'maintenance.ticket').exists():result={'state':'check_required','installation_performed':None}
    elif f.is_file():result=json.loads(f.read_text())
    elif (secure/'manager-handoff-result.json').is_file():
     from pending_attempt_recovery import _private_json
     result=_private_json(secure/'manager-handoff-result.json',4096)
     if type(result) is not dict or result.get('state') not in ('committed','rolled_back','aborted','restored_stopped','check_required'):raise ValueError('invalid_manager_result')
    else:result={'state':'idle','installation_performed':False}
   except Exception:result={'state':'check_required','installation_performed':None}
   return self.send(200,json.dumps(result).encode(),'application/json')
  if urlsplit(self.path).path=='/api/rapbrain/creative-install-state':
   f=root/'creative-install-result.json'
   try:output=json.loads(f.read_text()) if f.is_file() else {'state':'idle','installation_performed':False}
   except (OSError,ValueError):output={'state':'refused','installation_performed':False}
   return self.send(200,json.dumps(output).encode(),'application/json')
  if urlsplit(self.path).path=='/api/rapbrain/creative-signed-state':
   f=root/'creative-signed-result.json'
   try:output=json.loads(f.read_text()) if f.exists() else {'state':'idle','signature_verified':False}
   except Exception:output={'state':'failed','signature_verified':False}
   return self.send(200,json.dumps(output).encode(),'application/json')
  if urlsplit(self.path).path=='/api/rapbrain/engine-trial-state':
   f=root/'engine-trial-result.json'
   try:output=json.loads(f.read_text()) if f.exists() else {'state':'idle'}
   except Exception:output={'state':'failed'}
   return self.send(200,json.dumps(output).encode(),'application/json')
  if urlsplit(self.path).path=='/api/rapbrain/rehearsal-state':
   f=root/'rehearsal-result.json'
   try: result=json.loads(f.read_text()) if f.is_file() else {'state':'idle'}
   except Exception: result={'state':'unknown'}
   return self.send(200,json.dumps(result).encode(),'application/json')
  if urlsplit(self.path).path=='/api/rapbrain/signed-state':
   f=root/'signed-state-result.json'
   try: output=json.loads(f.read_text()) if f.is_file() else {'state':'idle','verified':False}
   except (OSError,ValueError): output={'state':'unknown','verified':False}
   return self.send(200,json.dumps(output).encode(),'application/json')
  if urlsplit(self.path).path=='/api/rapbrain/launch-state':
   state_file=root/'launch-state-result.json'
   try: state=json.loads(state_file.read_text()) if state_file.is_file() else {'state':'idle','launched':False}
   except (ValueError,OSError): state={'state':'unknown','launched':False}
   return self.send(200,json.dumps(state).encode(),'application/json')
  if urlsplit(self.path).path=='/api/rapbrain/backups':return self.send(200,json.dumps(history()).encode(),'application/json')
  if urlsplit(self.path).path=='/api/rapbrain/health':return self.send(200,json.dumps(rap_health()).encode(),'application/json')
  if urlsplit(self.path).path=='/api/rapbrain/inventory':return self.send(200,json.dumps(data_inventory()).encode(),'application/json')
  if urlsplit(self.path).path=='/demo':return self.send(200,page(),'text/html; charset=utf-8')
  if urlsplit(self.path).path=='/api/demo/status':return self.send(200,json.dumps(snapshot()).encode(),'application/json')
  return super().do_GET()
 def do_POST(self):
  endpoint=urlsplit(self.path).path
  if endpoint=='/api/rapbrain/manager-update':
   if self.headers.get('X-RB-Manager-Token')!=signature_token or self.headers.get('Origin','') not in ('',f'http://127.0.0.1:{self.server.server_address[1]}'):
    return self.send(403,b'{"error":"unauthorized"}','application/json')
   req=root/'manager-update-request.json'
   if req.exists():return self.send(409,b'{"error":"already_pending"}','application/json')
   result=root/'manager-update-result.json'
   if result.is_file():
    try:previous=json.loads(result.read_text())
    except (OSError,ValueError):return self.send(409,b'{"error":"unknown_previous_state"}','application/json')
    if previous.get('state') in ('queued','handoff'):return self.send(409,b'{"error":"already_running"}','application/json')
   result.write_text(json.dumps({'state':'queued','installation_performed':False}))
   req.write_text(json.dumps({'action':'install-signed-manager'}))
   return self.send(202,b'{"state":"queued"}','application/json')
  if endpoint=='/api/rapbrain/creative-install':
   if self.headers.get('X-RB-Creative-Token')!=signature_token or self.headers.get('Origin','') not in ('',f'http://127.0.0.1:{self.server.server_address[1]}'):
    return self.send(403,b'{"error":"unauthorized"}','application/json')
   req=root/'creative-install-request.json'
   if req.exists():return self.send(409,b'{"error":"already_pending"}','application/json')
   result=root/'creative-install-result.json'
   if result.is_file():
    try:previous=json.loads(result.read_text())
    except (OSError,ValueError):return self.send(409,b'{"error":"unknown_previous_state"}','application/json')
    if previous.get('state') in ('queued','running'):return self.send(409,b'{"error":"already_running"}','application/json')
   result.write_text(json.dumps({'state':'queued','installation_performed':False}))
   req.write_text(json.dumps({'action':'install-signed-creative'}))
   return self.send(202,b'{"state":"queued"}','application/json')
  if endpoint=='/api/rapbrain/creative-signed-check':
   if self.headers.get('X-RB-Creative-Token')!=signature_token or self.headers.get('Origin','') not in ('',f'http://127.0.0.1:{self.server.server_address[1]}'):
    return self.send(403,b'{"error":"unauthorized"}','application/json')
   req=root/'creative-signed-request.json'
   if req.exists():return self.send(409,b'{"error":"already_pending"}','application/json')
   req.write_text(json.dumps({'action':'verify-signed-creative'}))
   return self.send(202,b'{"state":"queued"}','application/json')
  if endpoint=='/api/rapbrain/engine-trial':
   if self.headers.get('X-RB-Engine-Token')!=signature_token or self.headers.get('Origin','') not in ('',f'http://127.0.0.1:{self.server.server_address[1]}'):
    return self.send(403,b'{"error":"unauthorized"}','application/json')
   if (root/'engine-trial-request.json').exists():return self.send(409,b'{"error":"already_pending"}','application/json')
   (root/'engine-trial-request.json').write_text(json.dumps({'action':'trial'}))
   return self.send(202,b'{"state":"queued"}','application/json')
  if endpoint=='/api/rapbrain/rehearse-signed':
   if self.headers.get('X-RB-Rehearsal-Token')!=signature_token or self.headers.get('Origin','') not in ('',f'http://127.0.0.1:{self.server.server_address[1]}'):
    return self.send(403,b'{"error":"unauthorized"}','application/json')
   (root/'rehearsal-request.json').write_text(json.dumps({'action':'rehearse','token':signature_token}))
   return self.send(202,b'{"state":"started","message":"Repetition demarree. Le rapport est disponible via /api/rapbrain/rehearsal-state."}','application/json')
  if endpoint=='/api/rapbrain/check-signed':
   if self.headers.get('X-RB-Signature-Token')!=signature_token or self.headers.get('Origin','') not in ('',f'http://127.0.0.1:{self.server.server_address[1]}'):
    return self.send(403,b'{"error":"unauthorized"}','application/json')
   f=root/'signed-request.json'
   if f.exists():return self.send(409,b'{"error":"already_pending"}','application/json')
   f.write_text(json.dumps({'action':'verify','token':signature_token}))
   return self.send(202,b'{"state":"queued","verified":false}', 'application/json')
  if endpoint=='/api/rapbrain/start':
   if self.headers.get('X-RB-Launch-Token')!=launch_token or self.headers.get('Origin','') not in ('',f'http://127.0.0.1:{self.server.server_address[1]}'):
    return self.send(403,b'{"error":"unauthorized"}','application/json')
   return self.send(200,json.dumps(launch_request()).encode(),'application/json')
  if endpoint=='/api/rapbrain/restore-test':
   if self.headers.get('X-RB-Backup-Token')!=backup_token or self.headers.get('Origin','') not in ('',f'http://127.0.0.1:{self.server.server_address[1]}'):
    return self.send(403,b'{"error":"unauthorized"}','application/json')
   try:return self.send(200,json.dumps(verify_restore_to_separate_folder()).encode(),'application/json')
   except Exception as exc:return self.send(422,json.dumps({'ok':False,'error':type(exc).__name__,'message':str(exc)[:160]}).encode(),'application/json')
  if endpoint=='/api/rapbrain/backup':
   if self.headers.get('X-RB-Backup-Token')!=backup_token or self.headers.get('Origin','') not in ('',f'http://127.0.0.1:{self.server.server_address[1]}'):
    return self.send(403,b'{"error":"unauthorized"}','application/json')
   try:return self.send(200,json.dumps(backup_live_db()).encode(),'application/json')
   except Exception as exc:return self.send(422,json.dumps({'ok':False,'error':type(exc).__name__,'message':str(exc)[:160]}).encode(),'application/json')
  if not endpoint.startswith('/api/demo/'):return readonly_post(self)
  if self.headers.get('X-Demo-Token')!=auth:return self.send(403,b'{"error":"unauthorized"}','application/json')
  action=endpoint.rsplit('/',1)[-1]
  if action not in ('backup','update','restore'):return self.send(404,b'{"error":"unknown"}','application/json')
  try:
   if action=='backup':
    if backup.exists():return self.send(409,b'{"error":"backup_already_exists"}','application/json')
    shutil.copytree(active,backup)
   elif action=='update':
    if not backup.exists():return self.send(409,b'{"error":"backup_required"}','application/json')
    (active/'version.txt').write_text('2.0-test',encoding='utf8')
    with (active/'manager.py').open('ab') as f:f.write(b'\n# RC42 TEST-ONLY UPDATE IN TEMPORARY COPY\n')
   else:
    if not backup.exists():return self.send(409,b'{"error":"backup_required"}','application/json')
    for src in ('version.txt','library.json','manager.py'):
     shutil.copyfile(backup/src,active/src)
   return self.send(200,json.dumps({'ok':True,'action':action,'state':snapshot()}).encode(),'application/json')
  except Exception as e:return self.send(500,json.dumps({'error':type(e).__name__}).encode(),'application/json')
srv=m.ThreadingHTTPServer(('127.0.0.1',0),DemoHandler)
port=srv.server_address[1]
if port==8765:raise RuntimeError('production_port')
(root/'port.json').write_text(json.dumps({'port':port,'pid':os.getpid()}))
try:srv.serve_forever(poll_interval=.05)
finally:srv.server_close()
'''

def request(port,path='/',method='GET'):
    c=http.client.HTTPConnection('127.0.0.1',port,timeout=3)
    try:
        c.request(method,path)
        r=c.getresponse();return r.status,r.read()
    finally:c.close()

def port_in_use():
    try:
        return request(8765)[0] > 0
    except (OSError,TimeoutError,http.client.HTTPException):
        return False

# Rap Brain ordinary launch gate v1.
def __rb_ordinary_launch_guard_v1(backup_dir, rap_dir):
    import json as __rb_json
    import os as __rb_os
    import stat as __rb_stat
    __rb_state = backup_dir / 'secure-update'
    if __rb_state.is_symlink():
        raise RuntimeError('unsafe_update_state')
    if not __rb_state.exists():
        return
    __rb_info = __rb_state.stat()
    if (__rb_info.st_uid != __rb_os.getuid() or
            not __rb_stat.S_ISDIR(__rb_info.st_mode) or
            __rb_info.st_mode & 0o077):
        raise RuntimeError('unsafe_update_state')
    if __rb_os.path.lexists(__rb_state / 'maintenance.ticket'):
        raise RuntimeError('update_recovery_required')
    if __rb_os.path.lexists(__rb_state / 'bootstrap-intent.json'):
        raise RuntimeError('bootstrap_recovery_required')
    if __rb_os.path.lexists(__rb_state / 'maintenance-intent.json'):
        raise RuntimeError('update_recovery_required')
    __rb_journal = __rb_state / 'transaction.json'
    if __rb_os.path.lexists(__rb_journal):
        if __rb_journal.is_symlink():
            raise RuntimeError('update_recovery_required')
        __rb_jinfo = __rb_journal.stat()
        if (__rb_jinfo.st_uid != __rb_os.getuid() or
                not __rb_stat.S_ISREG(__rb_jinfo.st_mode) or
                __rb_jinfo.st_mode & 0o077 or
                __rb_jinfo.st_size > 8192):
            raise RuntimeError('update_recovery_required')
        try:
            with __rb_journal.open('rb') as __rb_stream:
                __rb_record = __rb_json.loads(__rb_stream.read(8193))
            __rb_id = __rb_record.get('id') if type(__rb_record) is dict else None
            if (type(__rb_record) is not dict or
                    __rb_record.get('phase') not in ('committed', 'rolled_back', 'aborted') or
                    __rb_record.get('source') != str(rap_dir) or
                    type(__rb_record.get('sequence')) is not int or
                    __rb_record['sequence'] < 1 or
                    type(__rb_record.get('mode')) is not int or
                    not 0 <= __rb_record['mode'] <= 0o777 or
                    type(__rb_id) is not str or len(__rb_id) != 32 or
                    any(__rb_c not in '0123456789abcdef' for __rb_c in __rb_id)):
                raise RuntimeError('update_recovery_required')
        except (ValueError, UnicodeError):
            raise RuntimeError('update_recovery_required')

def handle_launch_request(root, rap_dir, backup_dir, state):
    request_file=root/'launch-request.json'
    if not request_file.exists():return
    try:
        __rb_ordinary_launch_guard_v1(backup_dir, rap_dir)
        incoming=json.loads(request_file.read_text())
        request_file.unlink()
        if incoming.get('action')!='start' or incoming.get('script')!='server.py':
            raise RuntimeError('invalid_launch_request')
        script=rap_dir/'server.py'
        if not script.is_file() or script.is_symlink() or script.parent.resolve()!=rap_dir:
            raise RuntimeError('entrypoint_not_verified')
        if port_in_use():raise RuntimeError('port_8765_already_in_use')
        previous=state.get('process')
        if previous is not None and previous.poll() is None:raise RuntimeError('already_launched_by_manager')
        logs=backup_dir/'launch-logs'
        logs.mkdir(exist_ok=True)
        log_path=logs/('start-'+time.strftime('%Y%m%d-%H%M%S')+'.log')
        with log_path.open('xb') as log:
            import secrets as __rb_secrets
            __rb_token = __rb_secrets.token_hex(32)
            __rb_server_env = dict(os.environ, RB_UPDATE_PROBE_TOKEN=__rb_token)
            import hashlib as __rb_hashlib
            __rb_server_sha = __rb_hashlib.sha256(script.read_bytes()).hexdigest()
            proc=subprocess.Popen([sys.executable,'-u',str(script)],cwd=rap_dir,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True,env=__rb_server_env)
        state['process']=proc
        state['runtime_token']=__rb_token
        state['server_sha256']=__rb_server_sha
        state['process_start_token']=None
        try:
            import re as __rb_re
            __rb_ps=subprocess.run(['/bin/ps','-p',str(proc.pid),'-o','lstart='],
                capture_output=True,text=True,timeout=5,stdin=subprocess.DEVNULL)
            __rb_raw=__rb_ps.stdout.strip()
            if (__rb_ps.returncode==0 and not __rb_ps.stderr and
                    __rb_re.fullmatch(r'[A-Z][a-z]{2} +[A-Z][a-z]{2} +[ 0-9]{1,2} +[0-9]{2}:[0-9]{2}:[0-9]{2} +[0-9]{4}',__rb_raw) and
                    proc.poll() is None):
                state['process_start_token']=str(proc.pid)+':'+ ' '.join(__rb_raw.split())
        except (OSError,subprocess.SubprocessError):
            pass
        report={'state':'spawned','launched':True,'pid':proc.pid,'log_path':str(log_path),'note':'Démarrage demandé explicitement. Vérifier ensuite le statut HTTP. Arrêt automatique désactivé.'}
    except Exception as exc:
        report={'state':'refused','launched':False,'error':str(exc)[:180]}
    (root/'launch-state-result.json').write_text(json.dumps(report,ensure_ascii=False))

def handle_signature_request(root, state, verifier):
    f=root/'signed-request.json'
    if not f.exists():return
    try:
        obj=json.loads(f.read_text()); f.unlink()
        if obj.get('action')!='verify':raise ValueError('invalid_request')
        if state.get('running'):raise ValueError('verification_in_progress')
        state['running']=True
        try:
            # No private key is accessed, no app code executed or installed.
            result=subprocess.run([sys.executable,str(verifier)],capture_output=True,text=True,timeout=80)
            data=json.loads(result.stdout) if result.stdout.strip() else {'verified':False,'detail':result.stderr[-300:]}
            if result.returncode!=0:data['verified']=False
        finally: state['running']=False
        data['state']='finished';data['production_update_authorized']=False
    except Exception as exc:data={'state':'refused','verified':False,'reason':type(exc).__name__,'production_update_authorized':False}
    (root/'signed-state-result.json').write_text(json.dumps(data,ensure_ascii=False))

def handle_rehearsal_request(root, state, runner, verifier):
    req=root/'rehearsal-request.json'
    if not req.exists():return
    try:
        request_data=json.loads(req.read_text())
        if request_data.get('action')!='rehearse':raise ValueError('invalid_action')
        req.unlink()
        result_file=root/'rehearsal-result.json'
        result_file.write_text(json.dumps({'state':'running'}))
        p=subprocess.run([sys.executable,str(runner),'--verifier',str(verifier)],capture_output=True,text=True,timeout=95)
        result=json.loads(p.stdout.strip()) if p.stdout.strip() else {'state':'failed','reason':p.stderr[-300:]}
        result_file.write_text(json.dumps(result,ensure_ascii=False))
    except Exception as exc:
        (root/'rehearsal-result.json').write_text(json.dumps({'state':'failed','error':type(exc).__name__,'reason':str(exc)[:200]}))

def handle_engine_trial(root, script):
    req=root/'engine-trial-request.json'
    if not req.exists():return
    req.unlink()
    out=root/'engine-trial-result.json'
    out.write_text(json.dumps({'state':'running'}))
    try:
        p=subprocess.run([sys.executable,str(script)],capture_output=True,text=True,timeout=35)
        result=json.loads(p.stdout.strip()) if p.stdout.strip() else {'result':'FAILED','reason':p.stderr[-200:]}
        result['state']='finished' if p.returncode==0 and result.get('result')=='PASS' else 'failed'
    except Exception as exc:result={'state':'failed','reason':str(exc)[:180]}
    out.write_text(json.dumps(result,ensure_ascii=False))

def handle_creative_signed_request(root, verifier):
    req=root/'creative-signed-request.json'
    if not req.exists():return
    req.unlink()
    out=root/'creative-signed-result.json'
    out.write_text(json.dumps({'state':'running','production_installation':False}))
    try:
        env=dict(os.environ, RB_P10_REPORT=str(root/'creative-verify-report.json'), PYTHONDONTWRITEBYTECODE='1')
        result=subprocess.run([sys.executable,'-B',str(verifier)],capture_output=True,text=True,timeout=70,env=env)
        report=json.loads(result.stdout) if result.stdout.strip() else {'state':'REFUSED','reason':result.stderr[-300:]}
        report['state']='finished' if result.returncode==0 and report.get('state')=='PASS_SIGNED_STAGING_ROLLBACK' else 'refused'
        report['production_installation']=False
        report['manager_beta14_real_install_enabled']=False
    except Exception as exc:
        report={'state':'refused','reason':type(exc).__name__,'production_installation':False,'manager_beta14_real_install_enabled':False}
    out.write_text(json.dumps(report,ensure_ascii=False))

def handle_creative_install_request(root, rap_dir, backup_dir, state):
    req=root/'creative-install-request.json'
    if not req.exists():return
    out=root/'creative-install-result.json'
    try:
        if req.is_symlink() or req.stat().st_size>1024:raise RuntimeError('invalid_install_request')
        data=json.loads(req.read_bytes())
        req.unlink()
        if data!={'action':'install-signed-creative'}:raise RuntimeError('invalid_install_request')
        out.write_text(json.dumps({'state':'running','installation_performed':False}))
        from creative_install_controller import install_owned_creative
        result=install_owned_creative(rap_dir,backup_dir/'secure-update',state)
        if type(result) is not dict or result.get('state') not in ('committed','rolled_back','aborted','restored_stopped'):
            raise RuntimeError('unexpected_install_result')
        result=dict(result)
        result['outcome']=result['state']
        result['state']='finished' if result['outcome']=='committed' else 'refused'
        out.write_text(json.dumps(result,ensure_ascii=False))
    except Exception as exc:
        out.write_text(json.dumps({'state':'refused','installation_performed':False,
            'reason':type(exc).__name__,'detail':str(exc)[:160]},ensure_ascii=False))

def handle_manager_update_request(root, rap_dir, backup_dir, state):
    req=root/'manager-update-request.json'
    if not req.exists():return False
    out=root/'manager-update-result.json'
    try:
        if req.is_symlink() or req.stat().st_size>1024:raise RuntimeError('invalid_manager_request')
        data=json.loads(req.read_bytes())
        req.unlink()
        if data!={'action':'install-signed-manager'}:raise RuntimeError('invalid_manager_request')
        secure_state=backup_dir/'secure-update'
        from manager_helper_release import verify_staged
        import sys
        helper_dir=verify_staged(secure_state)
        sys.path.insert(0,str(helper_dir))
        from manager_update_parent import prepare_handoff
        handoff=prepare_handoff(rap_dir,Path(__file__).resolve(),secure_state,
            state,secure_state/'helper'/'manager_update_helper.py')
        out.write_text(json.dumps({'state':'handoff','installation_performed':False}))
        handoff.release_for_parent_exit()
        return True
    except Exception as exc:
        out.write_text(json.dumps({'state':'refused','installation_performed':False,
            'reason':type(exc).__name__,'detail':str(exc)[:160]},ensure_ascii=False))
        return False

def main():
    p=argparse.ArgumentParser(description='Rap Brain Manager Beta 8 : verification de signature en lecture seule')
    p.add_argument('--candidate',type=Path,default=Path(__file__).resolve().parent/'candidate')
    p.add_argument('--no-browser',action='store_true')
    p.add_argument('--rap-brain-dir',type=Path,default=Path.home()/'Downloads'/'rap-brain',help='Dossier de Rap Brain à détecter (lecture seule)')
    p.add_argument('--smoke-test',action='store_true')
    p.add_argument('--backup-dir',type=Path,default=Path.home()/'Downloads'/'RapBrainManagerBackups',help='Répertoire persistant réservé aux sauvegardes')
    args=p.parse_args()
    candidate=args.candidate
    rap_dir=args.rap_brain_dir.expanduser().resolve()
    source=candidate/'Contents'/'Resources'/'manager.py'
    backup_dir=args.backup_dir.expanduser().absolute()
    if backup_dir.is_symlink() or backup_dir==rap_dir or backup_dir.is_relative_to(rap_dir) or rap_dir.is_relative_to(backup_dir):
        print('REFUSED: dossier de sauvegarde non séparé',file=sys.stderr);return 2
    backup_dir.mkdir(parents=True,exist_ok=True)
    backup_dir=backup_dir.resolve()
    demo=source.parent/'demo_release'/'manifest.json'
    if candidate.is_symlink() or source.is_symlink() or demo.is_symlink() or not source.is_file() or not demo.is_file():
        print('RC40 REFUSED: candidate RC39 ou ses ressources introuvables',file=sys.stderr);return 2
    raw=source.read_bytes();before=hashlib.sha256(raw).hexdigest()
    if any(marker not in raw for marker in [b'class Handler(',b'def do_GET(',b'def do_POST(']):
        print('RC40 REFUSED: structure manager.py inattendue',file=sys.stderr);return 2
    with tempfile.TemporaryDirectory(prefix='rapbrain-manager-beta-') as td:
        root=Path(td).resolve();(root/'manager.py').write_bytes(raw)
        shutil.copyfile(Path(__file__).with_name('dashboard_beta14.html'),root/'dashboard_beta14.html')
        shutil.copyfile(Path(__file__).with_name('beta13-icon.png'),root/'beta13-icon.png')
        (root/'demo_release').mkdir();shutil.copyfile(demo,root/'demo_release'/'manifest.json')
        env={'PATH':'/usr/bin:/bin','HOME':str(root),'TMPDIR':str(root),'LANG':'C','RAP_BRAIN_MANAGER_NO_BROWSER':'1','PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1'}
        proc=subprocess.Popen([sys.executable,'-I','-B','-c',CHILD,str(root),str(root/'manager.py'),str(rap_dir),str(backup_dir)],cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        try:
            for _ in range(160):
                if proc.poll() is not None:raise RuntimeError('Le Manager a quitté : '+proc.stderr.read().decode(errors='replace')[-1200:])
                if (root/'port.json').exists():break
                time.sleep(.05)
            else:raise RuntimeError('Aucun démarrage HTTP détecté')
            port=json.loads((root/'port.json').read_text())['port']
            code,body=request(port)
            if code!=200 or b'Rap Brain' not in body:raise RuntimeError('Interface HTTP inaccessible')
            if b'Beta 14' not in body or b'copyLog' not in body or b'beta13-icon.png' not in body:raise RuntimeError('Beta 13 UI missing')
            code,body=request(port,'/api/status')
            if code!=200 or not isinstance(json.loads(body),dict):raise RuntimeError('Statut HTTP invalide')
            if Path(json.loads(body)['source']).resolve()!=rap_dir:raise RuntimeError('Chemin de Rap Brain incorrect')
            code,_=request(port,'/api/prepare','POST')
            if code!=403:raise RuntimeError('Ecriture POST non bloquée')
            code,_=request(port,'/api/install-permanent','POST')
            if code!=403:raise RuntimeError('Installation non bloquée')
            code,_=request(port,'/api/check-public-channel','POST')
            if code!=403:raise RuntimeError('Contrôle GitHub sans jeton accepté')
            code,demo_body=request(port,'/demo')
            if code!=200 or b'version b' not in demo_body:raise RuntimeError('Atelier inaccessible')
            code,health_body=request(port,'/api/rapbrain/health')
            if code!=200 or 'reachable' not in json.loads(health_body):raise RuntimeError('Etat serveur inaccessible')
            code,inv_body=request(port,'/api/rapbrain/inventory')
            if code!=200 or 'candidates' not in json.loads(inv_body):raise RuntimeError('Inventaire inaccessible')
            code,hist_body=request(port,'/api/rapbrain/backups')
            if code!=200 or 'backups' not in json.loads(hist_body):raise RuntimeError('Historique inaccessible')
            code,_=request(port,'/api/rapbrain/restore-test','POST')
            if code!=403:raise RuntimeError('Restauration sans jeton acceptée')
            code,_=request(port,'/api/rapbrain/rehearse-signed','POST')
            if code!=403:raise RuntimeError('Rehearsal without token accepted')
            code,_=request(port,'/api/rapbrain/check-signed','POST')
            if code!=403:raise RuntimeError('Signed check without token accepted')
            code,signed_state=request(port,'/api/rapbrain/signed-state')
            if code!=200 or json.loads(signed_state).get('verified') is not False:raise RuntimeError('Signed state invalid')
            code,_=request(port,'/api/rapbrain/manager-update','POST')
            if code!=403:raise RuntimeError('Manager update without token accepted')
            code,body=request(port,'/api/rapbrain/manager-update-state')
            if code!=200 or json.loads(body).get('state')!='idle':raise RuntimeError('Manager update state invalid')
            code,_=request(port,'/api/rapbrain/creative-install','POST')
            if code!=403:raise RuntimeError('Creative install without token accepted')
            code,state_body=request(port,'/api/rapbrain/creative-install-state')
            if code!=200 or json.loads(state_body).get('state')!='idle':raise RuntimeError('Creative install state invalid')
            code,_=request(port,'/api/rapbrain/backup','POST')
            if code!=403:raise RuntimeError('Sauvegarde sans jeton acceptée')
            code,status_body=request(port,'/api/demo/status')
            if code!=200 or json.loads(status_body)['version']!='1.0-test':raise RuntimeError('Etat initial invalide')
            code,_=request(port,'/api/demo/update','POST')
            if code!=403:raise RuntimeError('POST sans token accepté')
            if not (root/'rapbrain_fictif'/'manager.py').is_file():raise RuntimeError('La copie du vrai manager.py est absente')
            if hashlib.sha256(source.read_bytes()).hexdigest()!=before:raise RuntimeError('Candidate modifiée')
            print(json.dumps({'result':'PASS','real_manager_ui':True,'demo_atelier':True,'real_manager_copy_used':True,'open_rap_brain_link':True,'status':True,'post_disabled':True,'port':port,'production_port_untouched':True,'candidate_unchanged':True,'detected_rap_brain_path':str(rap_dir),'real_manager_mutations_disabled':True,'public_channel_check_auth_enabled':True,'rap_brain_health_endpoint':True,'data_inventory_read_only':True,'sqlite_backup_api_ready':True,'separate_restore_check_ready':True,'backup_without_token_denied':True,'manual_launch_controller_available':True,'signed_verification_available':True,'signed_copy_swap_rehearsal_available':True,'real_stop_disabled':True},ensure_ascii=False,indent=2),flush=True)
            if args.smoke_test:return 0
            url=f'http://127.0.0.1:{port}/'
            print('\nTableau de bord : '+url+'\nDossier Rap Brain consulté (lecture seule) : '+str(rap_dir)+'\nAtelier facultatif : '+url+'demo\nSeule la vérification informative GitHub est autorisée ; les modifications restent bloquées.\nCtrl+C pour fermer.\n',flush=True)
            if not args.no_browser:webbrowser.open(url)
            supervisor_state={}
            while proc.poll() is None:
                handle_launch_request(root,rap_dir,backup_dir,supervisor_state)
                handle_signature_request(root,supervisor_state,Path(__file__).with_name('verify_local_signed.py'))
                handle_rehearsal_request(root,supervisor_state,Path(__file__).with_name('rehearse_signed.py'),Path(__file__).with_name('verify_local_signed.py'))
                handle_engine_trial(root,Path(__file__).with_name('engine_update_trial.py'))
                handle_creative_signed_request(root,Path(__file__).with_name('verify_creative_signed_p10.py'))
                handle_creative_install_request(root,rap_dir,backup_dir,supervisor_state)
                if handle_manager_update_request(root,rap_dir,backup_dir,supervisor_state):return 0
                time.sleep(.2)
            raise RuntimeError('Le Manager s’est arrêté inattendu')
        except KeyboardInterrupt:
            print('\nAperçu arrêté.',flush=True);return 0
        except Exception as exc:
            print('RC40 REFUSED: '+str(exc),file=sys.stderr);proc.terminate();print(proc.communicate(timeout=3)[1].decode(errors='replace')[-2500:],file=sys.stderr);return 2
        finally:
            if proc.poll() is None:proc.terminate()
            try:proc.communicate(timeout=3)
            except subprocess.TimeoutExpired:proc.kill();proc.communicate(timeout=3)
if __name__=='__main__':raise SystemExit(main())
